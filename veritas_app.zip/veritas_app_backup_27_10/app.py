import os
import re
import uuid
import traceback
import json
import time
import subprocess  
from datetime import datetime
from copy import deepcopy
import threading
from flask import Flask, request, send_file, render_template, jsonify, Response, stream_with_context
from docx import Document
from openai import OpenAI
import locale
import pytz
import zipfile
import io
from pypdf import PdfReader
from docx import Document
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

load_dotenv(override=True)
current_key = os.environ.get("OPENAI_API_KEY", "")
if current_key:
    print(f"🔑 Using API Key ending in: ...{current_key[-4:]}")
else:
    print("❌ No API Key found in environment!")

app = Flask(__name__)


# initialize LLM client
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# Optional config
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.config['UPLOAD_FOLDER'] = os.path.join(BASE_DIR, "uploads")

# Δημιουργία φακέλων (Ασφάλεια για τον Server)
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])
if not os.path.exists(os.path.join(BASE_DIR, "generated_reports")):
    os.makedirs(os.path.join(BASE_DIR, "generated_reports"))

# =============================================================================
# INITIALIZE RAG VECTOR DATABASE (READ-ONLY)
# =============================================================================
CHROMA_DB_DIR = os.path.join(BASE_DIR, "chroma_db")
print("🧠 Loading RAG Vector Database...")
try:
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    vectorstore = Chroma(persist_directory=CHROMA_DB_DIR, embedding_function=embeddings)
    print("✅ RAG Vector Database loaded successfully!")
except Exception as e:
    print(f"⚠️ WARNING: Could not load ChromaDB. RAG context will be skipped. Error: {e}")
    vectorstore = None

# Global dictionary για την παρακολούθηση της προόδου των ασύγχρονων jobs
generation_jobs = {}

# =============================================================================
#  ΑΛΛΑΓΗ 2: ΝΕΑ ΣΥΝΑΡΤΗΣΗ ΓΙΑ PDF (LINUX/LIBREOFFICE)
# =============================================================================
def convert_docx_to_pdf_linux(docx_path, output_dir):
    """
    Μετατροπή DOCX σε PDF χρησιμοποιώντας LibreOffice (Linux).
    Αντικαθιστά την docx2pdf.
    """
    try:
        # Εντολή LibreOffice headless
        cmd = [
            'libreoffice', '--headless', '--convert-to', 'pdf',
            '--outdir', output_dir,
            docx_path
        ]
        print(f"🔄 Converting to PDF via LibreOffice: {docx_path}")
        subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        
        # Το LibreOffice σώζει με το ίδιο όνομα αλλά κατάληξη .pdf
        pdf_name = os.path.splitext(os.path.basename(docx_path))[0] + ".pdf"
        full_pdf_path = os.path.join(output_dir, pdf_name)
        
        if os.path.exists(full_pdf_path):
            print(f"✅ PDF Created: {full_pdf_path}")
            return full_pdf_path
        else:
            print("❌ PDF creation failed (file not found).")
            return None
    except Exception as e:
        print(f"⚠️ PDF Conversion Error: {e}")
        return None

# =============================================================================
#  ΟΛΟΣ Ο ΥΠΟΛΟΙΠΟΣ ΚΩΔΙΚΑΣ ΣΟΥ (ΑΚΡΙΒΩΣ ΟΠΩΣ ΤΟΝ ΑΝΕΒΑΣΕΣ)
# =============================================================================

def build_llm_context(params: dict) -> str:
    """
    Unified context block for ALL report types (short / standard / long).
    
    ΛΕΙΤΟΥΡΓΙΕΣ:
    - Συγκέντρωση metadata
    - Διαχείριση FILES vs TEXT input
    - Ενεργοποίηση Inference Mode (αν λείπουν όλα) vs Analysis Mode (αν υπάρχουν αρχεία)
    - Εφαρμογή πολιτικής γλώσσας
    """

    language = params.get("LANGUAGE", "en")
    
    # Έλεγχος αν έχουμε περιεχόμενο από αρχεία (PDF/DOCX/TXT)
    has_files = bool(params.get("SUPPORTING_DOCS_TEXT"))

    # --- Language instruction ---
    lang_instruction_map = {
        "en": "WRITE THE ENTIRE REPORT IN ENGLISH.",
        "el": "ΓΡΑΨΕ ΟΛΟ ΤΟ ΚΕΙΜΕΝΟ ΣΤΑ ΕΛΛΗΝΙΚΑ ΜΕ ΕΠΑΓΓΕΛΜΑΤΙΚΗ ΝΟΜΙΚΗ ΟΡΟΛΟΓΙΑ.",
    }
    lang_instruction = lang_instruction_map.get(language, lang_instruction_map["en"])

    # --- Βασικό context block με τα metadata ---
    context = f"""
===========================
APPLICATION CONTEXT FOR ANALYSIS
===========================

Application Name: {params.get("APPLICATION_NAME")}
Application URL: {params.get("application_url")}
Domain / Application Area: {params.get("application_area")}
Role under the EU AI Act: {params.get("organization_role")}
User-provided Risk Category: {params.get("risk_category")}
Selected Report Language: {params.get("LANGUAGE")}

APPLICATION DESCRIPTION (User Input):
{params.get("application_summary") or "(No summary provided by user)"}
"""

    # --- ΛΟΓΙΚΗ ΠΕΡΙΓΡΑΦΗΣ (DESCRIPTION DIRECTIVE) --- 
    # Εδώ καθορίζουμε αν το LLM θα διαβάσει, θα βασιστεί στο χρήστη ή θα μαντέψει.

    if not params.get("application_summary"):
        # ΠΕΡΙΠΤΩΣΗ A: Δεν υπάρχει περιγραφή, ΑΛΛΑ ΥΠΑΡΧΟΥΝ ΑΡΧΕΙΑ
        if has_files:
            context += """
DESCRIPTION DIRECTIVE (FILE-BASED):
The user did NOT provide a text summary, BUT has uploaded technical documentation (attached below).

You MUST:
1. Analyze the attached "UPLOADED TECHNICAL DOCUMENTATION" sections.
2. EXTRACT the system description, architecture, purpose, and risks strictly from those files.
3. Construct the JSON field 'APP_DESCRIPTION' based on the file content.
Do NOT invent functionalities that are not present in the files.
"""
        # ΠΕΡΙΠΤΩΣΗ B: Δεν υπάρχει περιγραφή, ΟΥΤΕ ΑΡΧΕΙΑ (Full Inference)
        else:
            context += """
DESCRIPTION GENERATION DIRECTIVE (INFERENCE):
The user did NOT provide an application description and NO files were uploaded.

You MUST generate a fully detailed, accurate and domain-aware description
of the AI system, based on:
- the application name
- the application area/domain
- typical ML/AI components involved in this domain
- known risks and operational characteristics

This generated description MUST be written into the JSON field APP_DESCRIPTION.
"""
    else:
        # ΠΕΡΙΠΤΩΣΗ C: Ο χρήστης έδωσε περιγραφή
        context += """
DESCRIPTION DIRECTIVE:
The user provided an application description.
You MUST use it as the basis for the JSON field APP_DESCRIPTION.
You MAY refine, reorganize, and extend it for clarity and completeness,
but you MUST preserve the factual meaning and system characteristics.
"""

    # --- Missing Information Detection ---
    # Αν έχουμε αρχεία (has_files), θεωρούμε ότι ΔΕΝ λείπουν πληροφορίες (Analysis Mode),
    # ακόμα και αν ο χρήστης άφησε κενά τα dropdowns.
    missing_info = any([
        not params.get("application_summary"),
        not params.get("organization_role"),
        not params.get("risk_category"),
        not params.get("application_area"),
    ]) and not has_files 

    if missing_info:
        context += """
===========================
INTELLIGENT INFERENCE MODE ENABLED
===========================

The user has provided partial or incomplete information.
You MUST NOT respond with "Insufficient information".

Instead:
- Infer reasonable technical properties of the AI system
  based on publicly known characteristics of similar systems.
- Use industry-standard assumptions when needed.
- Provide a full, detailed compliance assessment.
"""
    else:
        context += """
===========================
STRICT ANALYSIS MODE ENABLED
===========================

The user has provided explicit system information (or uploaded files).
Base the analysis STRICTLY on the provided details and documentation.
Avoid speculation unless logically necessary.
"""

    # --- Πολιτική γλώσσας: ΟΛΕΣ οι ΤΙΜΕΣ JSON στη γλώσσα του χρήστη ---
    context += """
===========================
LANGUAGE POLICY
===========================

All JSON VALUES (text fields) MUST be written entirely in the selected language.
No English residual text, no untranslated phrases, no mixed-language output.

This applies to:
- SUMMARY
- SCOPE
- APP_DESCRIPTION
- RISK_DETAILS_*
- RISK_LEVEL explanation
- TRANSPARENCY
- DATA_GOVERNANCE
- HUMAN_OVERSIGHT
- TECH_DOCS
- PERF_SAFETY
- AREAS_OF_COMPLIANCE
- GAPS_AND_RISKS
- RECOMMENDATIONS
- APPENDIX

Headings, bullet points, and sentences MUST all be in the selected language.
"""

    # --- Τελική οδηγία γλώσσας ---
    context += f"\n\n{lang_instruction}\n"

    # --- Supporting docs (ΕΔΩ ΚΟΛΛΑΜΕ ΤΑ ΑΡΧΕΙΑ) ---
    if has_files:
        context += "\n\n=======================================================\n"
        context += "   UPLOADED TECHNICAL DOCUMENTATION (PRIMARY SOURCE)\n"
        context += "=======================================================\n"
        context += "INSTRUCTIONS: The user has uploaded the following files.\n"
        context += "Use this content as the SOURCE OF TRUTH to fill in the Description, Architecture, and Risks.\n"
        context += "Ignore the 'Inference Mode' if the answers are found here.\n\n"
        
        # Κόβουμε στους 90.000 χαρακτήρες (ανέβασα λίγο το όριο για το GPT-4o)
        # Αυτό καλύπτει άνετα ~20-30 σελίδες πυκνού κειμένου.
        context += params["SUPPORTING_DOCS_TEXT"][:90000]
        
        if len(params["SUPPORTING_DOCS_TEXT"]) > 90000:
            context += "\n...[Text Truncated]..."

# --- RAG: ΔΥΝΑΜΙΚΗ ΑΝΑΚΤΗΣΗ ΝΟΜΙΚΟΥ ΠΛΑΙΣΙΟΥ (CONTEXT INJECTION) ---
    global vectorstore
    if vectorstore is not None:
        print("🔍 RAG: Searching for relevant EU AI Act articles...")
        
        # 1. Φτιάχνουμε το "ερώτημα" αναζήτησης με βάση τα δεδομένα του χρήστη
        search_query = expand_query_if_needed(params)        

        try:
            # 2. Ανάκτηση των 3 πιο σχετικών άρθρων του νόμου
            # Χρησιμοποιούμε k=3 για να μην υπερφορτώσουμε το context window
            docs = vectorstore.similarity_search(search_query, k=3)
            
            if docs:
                context += "\n\n=======================================================\n"
                context += "   OFFICIAL EU AI ACT LEGAL CONTEXT (RAG RETRIEVAL)\n"
                context += "=======================================================\n"
                context += "INSTRUCTIONS: You MUST base your compliance assessment strictly on the following retrieved articles.\n\n"
                
                for i, doc in enumerate(docs):
                    article_no = doc.metadata.get("article_no", "Unknown")
                    context += f"--- Article {article_no} ---\n{doc.page_content}\n\n"
                    
                print(f"✅ RAG: Injected {len(docs)} relevant articles into context.")
        except Exception as e:
            print(f"⚠️ RAG Search Error: {e}")
            
    return context

# =============================================================================
#  JSON HELPERS
# =============================================================================

def clean_json_string(json_str: str) -> str:
    """Aggressive cleaning of JSON string to avoid parsing errors."""
    json_str = json_str.encode('utf-8', 'ignore').decode('utf-8')

    def fix_string_value(match):
        content = match.group(1)
        content = content.replace('\n', ' ')
        content = content.replace('\r', ' ')
        content = content.replace('\t', ' ')
        content = re.sub(r'\s+', ' ', content)
        return f'"{content}"'

    json_str = re.sub(r'"([^"]*)"', fix_string_value, json_str)
    return json_str


def extract_json_from_llm_output(output_text: str) -> dict:
    """Robust extraction of the FIRST JSON object from an LLM response."""
    print("🔍 Starting JSON extraction...")

    if not output_text:
        print("❌ Empty LLM output")
        return {}

    # Remove markdown fences
    output_text = output_text.replace('```json', '')
    output_text = output_text.replace('```', '')

    # Try to find JSON object
    match = re.search(r'\{.*\}', output_text, re.DOTALL)
    if not match:
        print("❌ No JSON object found in LLM output.")
        return {}

    json_str = match.group()
    print(f"✅ Found JSON object, length: {len(json_str)} characters")

    print("🧹 Cleaning JSON string...")
    json_str = clean_json_string(json_str)

    try:
        print("🔍 Attempting JSON parse...")
        result = json.loads(json_str)
        print(f"✅ JSON parsed successfully! Fields: {len(result)}")
        return result
    except json.JSONDecodeError as e:
        print(f"⚠️ First parse failed: {e}")

        try:
            print("🔍 Attempting strict=False parse...")
            result = json.loads(json_str, strict=False)
            print(f"✅ Parsed successfully! Fields: {len(result)}")
            return result
        except Exception as e2:
            print(f"⚠️ Second parse failed: {e2}")

            try:
                print("🔍 Applying minor fixes (trailing commas)...")
                json_str = re.sub(r',\s*}', '}', json_str)
                json_str = re.sub(r',\s*]', ']', json_str)
                result = json.loads(json_str)
                print(f"✅ Parsed after fixes! Fields: {len(result)}")
                return result
            except Exception as e3:
                print(f"❌ All parse attempts failed: {e3}")
                print("📄 First 500 chars of problematic JSON:")
                print(json_str[:500])
                return {}


def replace_placeholder_in_paragraph(paragraph, placeholder, replacement):
    """
    Replace [PLACEHOLDER] inside a paragraph WITHOUT losing formatting (font, bold, etc).
    Supports also lists/dicts (serializes them to readable text).
    """

    def serialize_value(value):
        if value is None:
            return ""

        # simple types
        if isinstance(value, str):
            return value
        if isinstance(value, (int, float)):
            return str(value)

        # lists → bullet blocks
        if isinstance(value, list):
            lines = []
            for item in value:

                if isinstance(item, dict):
                    name = (
                        item.get("NAME")
                        or item.get("TITLE")
                        or item.get("ROLE")
                        or item.get("ID")
                        or item.get("USE_CASE_NAME")
                        or item.get("DATASET_ID")
                    )

                    desc = (
                        item.get("DESCRIPTION")
                        or item.get("SUMMARY")
                        or item.get("DETAILS")
                        or item.get("RESPONSIBILITIES")
                    )

                    ai_func = (
                        item.get("AI_FUNCTION")
                        or item.get("FUNCTION")
                        or item.get("AI_COMPONENT")
                        or item.get("SYSTEM_PART")
                        or item.get("MODEL_TYPE")
                    )

                    risk = (
                        item.get("RISK_ASPECTS")
                        or item.get("RISK_IMPACT")
                        or item.get("RISK_LEVEL")
                        or item.get("IMPACT")
                        or item.get("RISK_EXPOSURE")
                    )

                    block = []

                    # name
                    if name:
                        block.append("• " + str(name))
                    else:
                        # fallback όταν δεν υπάρχει όνομα
                        block.append("• " + "; ".join(f"{k}: {v}" for k, v in item.items()))

                    # desc
                    if desc:
                        block.append("    Description: " + str(desc))

                    # function
                    if ai_func:
                        block.append("    AI Function: " + str(ai_func))

                    # risk
                    if risk:
                        block.append("    Risk Aspects: " + str(risk))

                    lines.append("\n".join(block))

                else:
                    lines.append("• " + str(item))

            return "\n\n".join(lines)

        # standalone dict
        if isinstance(value, dict):
            return "\n".join(f"{k}: {v}" for k, v in value.items())

        return str(value)

    # STOP: if placeholder not inside paragraph
    if placeholder not in paragraph.text:
        return False

    replacement = serialize_value(replacement)

    # fix Greek unicode mojibake issue for docx
    if isinstance(replacement, str):
        try:
            replacement = replacement.encode("utf-8").decode("utf-8")
        except:
            pass

    runs = paragraph.runs

    # simple case → 1 run
    if len(runs) <= 1:
        if runs:
            run = runs[0]
            original_font_name = run.font.name
            original_font_size = run.font.size
            original_bold = run.font.bold
            original_italic = run.font.italic
            original_underline = run.font.underline
            original_color = run.font.color.rgb if run.font.color.rgb else None

            run.text = run.text.replace(placeholder, replacement)

            if original_font_name:
                run.font.name = original_font_name
            if original_font_size:
                run.font.size = original_font_size
            if original_bold is not None:
                run.font.bold = original_bold
            if original_italic is not None:
                run.font.italic = original_italic
            if original_underline is not None:
                run.font.underline = original_underline
            if original_color:
                run.font.color.rgb = original_color
        return True

    # complex case → placeholder spans multiple runs
    full_text = paragraph.text
    current_pos = 0
    placeholder_start = full_text.find(placeholder)
    placeholder_end = placeholder_start + len(placeholder)

    for i, run in enumerate(runs):
        run_text = run.text
        run_start = current_pos
        run_end = current_pos + len(run_text)

        # check if placeholder starts inside this run
        if run_start <= placeholder_start < run_end:
            original_font_name = run.font.name
            original_font_size = run.font.size
            original_bold = run.font.bold
            original_italic = run.font.italic
            original_underline = run.font.underline
            original_color = run.font.color.rgb if run.font.color.rgb else None

            # full replace if ends inside same run
            if placeholder_end <= run_end:
                run.text = run.text.replace(placeholder, replacement)
            else:
                # merge runs and replace once
                merged_text = ''.join(r.text for r in runs[i:])
                merged_text = merged_text.replace(placeholder, replacement, 1)
                for j in range(i + 1, len(runs)):
                    runs[j].text = ''
                runs[i].text = merged_text

            # restore formatting
            if original_font_name:
                runs[i].font.name = original_font_name
            if original_font_size:
                runs[i].font.size = original_font_size
            if original_bold is not None:
                runs[i].font.bold = original_bold
            if original_italic is not None:
                runs[i].font.italic = original_italic
            if original_underline is not None:
                runs[i].font.underline = original_underline
            if original_color:
                runs[i].font.color.rgb = original_color

            return True

        current_pos = run_end

    return False

def apply_markdown_styling(doc):
    """
    Σαρώνει όλο το έγγραφο (παραγράφους και πίνακες) για Markdown bold syntax (**text**)
    και το μετατρέπει σε πραγματικό Word Bold format, αφαιρώντας τους αστερίσκους.
    """
    import re
    # Βρίσκει κείμενο ανάμεσα σε διπλούς αστερίσκους: **κάτι**
    bold_pattern = re.compile(r'\*\*(.*?)\*\*')

    def process_paragraph(paragraph):
        # Αν δεν έχει αστερίσκους, προχωράμε
        if "**" not in paragraph.text:
            return

        # Κρατάμε το στυλ (font/size/color) από το πρώτο run της παραγράφου
        # για να το εφαρμόσουμε στα νέα κομμάτια (ώστε να μην χαθεί το format του template)
        original_runs = paragraph.runs
        base_font_name = None
        base_font_size = None
        base_color = None
        
        if original_runs:
            base_font_name = original_runs[0].font.name
            base_font_size = original_runs[0].font.size
            if original_runs[0].font.color.rgb:
                base_color = original_runs[0].font.color.rgb

        full_text = paragraph.text
        # Το split χωρίζει το κείμενο σε: [Κανονικό, Bold, Κανονικό, Bold...]
        parts = bold_pattern.split(full_text)

        # Καθαρίζουμε την παλιά παράγραφο
        paragraph.clear()

        for i, part in enumerate(parts):
            if not part: continue

            run = paragraph.add_run(part)

            # Επαναφορά αρχικού στυλ (για να μην χαλάσει η γραμματοσειρά του Template)
            if base_font_name: run.font.name = base_font_name
            if base_font_size: run.font.size = base_font_size
            if base_color: run.font.color.rgb = base_color

            # Τα μονά indices (1, 3, 5...) είναι αυτά που ήταν μέσα σε **...**
            if i % 2 == 1:
                run.font.bold = True

    # 1. Επεξεργασία κύριων παραγράφων
    for p in doc.paragraphs:
        process_paragraph(p)

    # 2. Επεξεργασία πινάκων (γιατί το κείμενο μπορεί να είναι σε κελί)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    process_paragraph(p)

    print("✅ Markdown bold styling applied successfully.")
    return doc

# =============================================================================
#  SMART PLACEHOLDER FILLER (OPTIONAL AUTO-FILL FOR SHORT TEMPLATE)
# =============================================================================

class SmartPlaceholderFiller:
    """Optional smart filler for generic [X], [Y], [AUTO] κλπ σε short / standard templates."""

    @staticmethod
    def extract_score_from_text(text, default=70):
        if not text:
            return default

        patterns = [
            r'(\d+)\s*/\s*100',
            r'(\d+)\s*%',
            r'score[:\s]+(\d+)',
            r'βαθμολογία[:\s]+(\d+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, str(text), re.IGNORECASE)
            if match:
                try:
                    score = int(match.group(1))
                    if 0 <= score <= 100:
                        return score
                except Exception:
                    continue
        return default

    @staticmethod
    def extract_count_from_text(text, keyword, default=0):
        if not text or not keyword:
            return default

        text = str(text)
        keywords = keyword.split('|')

        for kw in keywords:
            kw = kw.strip()
            if not kw:
                continue

            patterns = [
                rf'(\d+)\s+{re.escape(kw)}',
                rf'{re.escape(kw)}[:\s]+(\d+)',
                rf'{re.escape(kw)}\s*\((\d+)\)',
                rf'\b(\d+)\s*{re.escape(kw)}',
            ]
            for pattern in patterns:
                try:
                    m = re.search(pattern, text, re.IGNORECASE)
                    if m and m.group(1):
                        count = int(m.group(1))
                        if count >= 0:
                            return count
                except Exception:
                    continue

        return default

    @staticmethod
    def extract_actions_from_recommendations(recommendations_text, count=3):
        if isinstance(recommendations_text, list):
            recommendations_text = "\n".join(str(item) for item in recommendations_text)

        if not recommendations_text:
            return [
                "Improve documentation and compliance",
                "Enhance transparency mechanisms",
                "Strengthen data governance"
            ]

        pattern = r'(?:^\d+\.|Recommendation\s+\d+|Σύσταση\s+\d+)[:\s]+(.+?)(?=\n\d+\.|\nRecommendation|\nΣύσταση|$)'
        matches = re.findall(pattern, str(recommendations_text), re.MULTILINE | re.IGNORECASE)

        if matches:
            actions = []
            for match in matches[:count]:
                action = match.strip()
                action = re.sub(r'\(.*?\)', '', action).strip()
                if action:
                    actions.append(action[:100])
            while len(actions) < count:
                actions.append("Continue compliance improvement efforts")
            return actions[:count]

        lines = str(recommendations_text).split('\n')
        actions = []
        for line in lines:
            clean = re.sub(r'\(.*?\)', '', line).strip()
            if len(clean) > 20:
                actions.append(clean[:100])
            if len(actions) >= count:
                break

        if len(actions) < count:
            defaults = [
                "Implement comprehensive logging system",
                "Enhance data governance framework",
                "Develop bias testing protocols",
                "Improve technical documentation",
                "Strengthen human oversight mechanisms"
            ]
            actions.extend(defaults)

        return actions[:count]

    @staticmethod
    def replace_in_run_preserve_format(run, old_text, new_text):
        if old_text not in run.text:
            return False

        original_font_name = run.font.name
        original_font_size = run.font.size
        original_bold = run.font.bold
        original_italic = run.font.italic
        original_underline = run.font.underline
        original_color = run.font.color.rgb if run.font.color.rgb else None

        run.text = run.text.replace(old_text, new_text)

        if original_font_name:
            run.font.name = original_font_name
        if original_font_size:
            run.font.size = original_font_size
        if original_bold is not None:
            run.font.bold = original_bold
        if original_italic is not None:
            run.font.italic = original_italic
        if original_underline is not None:
            run.font.underline = original_underline
        if original_color:
            run.font.color.rgb = original_color

        return True

    @staticmethod
    def replace_in_paragraph_preserve_format(paragraph, old_text, new_text):
        if old_text not in paragraph.text:
            return False
        replaced = False
        for run in paragraph.runs:
            if old_text in run.text:
                SmartPlaceholderFiller.replace_in_run_preserve_format(run, old_text, new_text)
                replaced = True
        return replaced

    @staticmethod
    def fill_smart_placeholders(doc, data):
        """
        Προαιρετική "έξυπνη" συμπλήρωση για placeholders όπως:
        [X]/100, [X], [AUTO-GENERATED], [Action 1], κτλ.
        Αν δεν υπάρχουν αυτά στο template σου, δεν επηρεάζει κάτι.
        """
        try:
            final_score_text = data.get('FINAL_SCORE', '')
            scores_overall = SmartPlaceholderFiller.extract_score_from_text(final_score_text, 72)

            gaps_text = data.get('GAPS_AND_RISKS', '')
            total_gaps = (
                SmartPlaceholderFiller.extract_count_from_text(gaps_text, 'Critical|Κρίσιμ', 2) +
                SmartPlaceholderFiller.extract_count_from_text(gaps_text, 'High|Υψηλ', 3) +
                SmartPlaceholderFiller.extract_count_from_text(gaps_text, 'Medium|Μέτρι', 4) +
                SmartPlaceholderFiller.extract_count_from_text(gaps_text, 'Low|Χαμηλ', 2)
            )

            rec_text = data.get('RECOMMENDATIONS', '')
            actions = SmartPlaceholderFiller.extract_actions_from_recommendations(rec_text, 3)

            target_score = min(100, scores_overall + 13)
            improvement_needed = target_score - scores_overall

            replacements = {
                '[X]/100': f"{scores_overall}/100",
                '[Y]/100': f"{target_score}/100",
                '[Z]/100': f"{improvement_needed}/100",
                '[X]': str(total_gaps),
                '[AUTO-GENERATED]': f"REP-{datetime.now().strftime('%Y%m%d-%H%M%S')}",
                '[Action 1]': actions[0] if len(actions) > 0 else 'Improve compliance',
                '[Action 2]': actions[1] if len(actions) > 1 else 'Enhance documentation',
                '[Action 3]': actions[2] if len(actions) > 2 else 'Strengthen data governance',
            }

            replaced_count = 0

            for paragraph in doc.paragraphs:
                for old, new in replacements.items():
                    if SmartPlaceholderFiller.replace_in_paragraph_preserve_format(paragraph, old, str(new)):
                        replaced_count += 1

            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        for paragraph in cell.paragraphs:
                            for old, new in replacements.items():
                                SmartPlaceholderFiller.replace_in_paragraph_preserve_format(paragraph, old, str(new))

            print(f"✅ Smart placeholder filling completed - {replaced_count} replacements")
            return doc

        except Exception as e:
            print(f"⚠️ Error in smart placeholder filling: {e}")
            return doc


# =============================================================================
#  WORD TEMPLATE FILLER (WITH REPEAT TABLES)
# =============================================================================

def fill_template(template_path, data):
    """
    Fill a Word template with data.
    - Preserves formatting
    - Supports [PLACEHOLDERS] in paragraphs and tables
    - Supports REPEAT tables: [REPEAT:KEY] + template row
    - Applies SmartPlaceholderFiller at the end
    Returns the path to the generated .docx.
    """

    from docx.table import _Cell

    print(f"\n📄 fill_template called")
    print(f"   Template: {os.path.basename(template_path)}")
    print(f"   Data fields: {len(data)}")

    doc = Document(template_path)

    # ==========================================================
    #  UNIFIED ADVANCED SERIALIZER (paragraphs + tables)
    # ==========================================================
    def advanced_serialize(value):
        """
        Serializer με Smart Formatting:
        - Διατηρεί τις κενές γραμμές.
        - Βάζει αυτόματα αποστάσεις ανάμεσα σε Recommendation Items (Priority/Action).
        """
        if value is None:
            return ""

        # --- SMART STRING HANDLING ---
        if isinstance(value, str):
            # 1. Έξυπνος διαχωρισμός: Αν βρούμε "Priority:" κολλημένο σε προηγούμενη γραμμή, βάζουμε κενό.
            # (Ψάχνει για αλλαγή γραμμής \n ακολουθούμενη από Priority/Σύσταση και βάζει \n\n)
            if "Priority:" in value or "Σύσταση" in value:
                value = re.sub(r'\n(?=\s*(?:Priority|Σύσταση|Recommendation)\s*:)', '\n', value)

            # 2. Καθαρισμός, αλλά με σεβασμό στις παραγράφους
            if "\n" in value:
                lines = value.split('\n')
                cleaned_lines = []
                for line in lines:
                    # Καθαρίζουμε τα κενά μέσα στη γραμμή (trim), αλλά κρατάμε τη γραμμή ακόμα κι αν είναι κενή
                    s = re.sub(r'\s+', ' ', line).strip()
                    cleaned_lines.append(s)
                
                # Ενώνουμε με \n. Αν υπάρχουν κενές γραμμές στη λίστα (από το split), 
                # θα γίνουν \n\n στο τελικό string, δημιουργώντας το κενό που θες.
                return "\n".join(cleaned_lines)
            
            # Μονή γραμμή
            return re.sub(r'\s+', ' ', value).strip()

        if isinstance(value, (int, float)):
            return str(value)

        # --- LIST HANDLING (Παραμένει ίδιο, ήδη βάζει \n\n) ---
        if isinstance(value, list):
            lines = []
            for item in value:
                if isinstance(item, dict):
                    # TRY COMMON KEYS
                    name = (
                        item.get("NAME") or item.get("TITLE") or item.get("ROLE")
                        or item.get("ID") or item.get("USE_CASE_NAME")
                        or item.get("DATASET_ID") or item.get("METRIC")
                        or item.get("CASE_TITLE")
                    )
                    desc = (
                        item.get("DESCRIPTION") or item.get("SUMMARY")
                        or item.get("DETAILS") or item.get("RESPONSIBILITIES")
                        or item.get("IMPACT")
                    )
                    ai_func = (
                        item.get("AI_FUNCTION") or item.get("FUNCTION")
                        or item.get("MODEL_TYPE") or item.get("SYSTEM_COMPONENT")
                        or item.get("MODULE")
                    )
                    risk = (
                        item.get("RISK_ASPECTS") or item.get("RISK_IMPACT")
                        or item.get("RISK_LEVEL") or item.get("SEVERITY")
                        or item.get("RISK_EXPOSURE")
                    )

                    # Δομή Block
                    block = []
                    if name:
                        block.append("• " + str(name))
                    else:
                        # Fallback: Αν είναι dict χωρίς name, τυπώνουμε τα περιεχόμενα
                        # Εδώ βάζουμε Priority, Owner κλπ αν έρθουν ως απλό dict
                        kv_pairs = []
                        for k, v in item.items():
                             kv_pairs.append(f"{k}: {v}")
                        block.append("• " + "\n  ".join(kv_pairs))

                    if desc: block.append("    Description: " + str(desc))
                    if ai_func: block.append("    AI Function: " + str(ai_func))
                    if risk: block.append("    Risk Aspects: " + str(risk))

                    lines.append("\n".join(block))

                else:
                    lines.append("• " + str(item))

            # ΕΔΩ: Το \n εξασφαλίζει κενό ανάμεσα στα αντικείμενα της λίστας
            return "\n".join(lines)

        # DICT → prettyprint
        if isinstance(value, dict):
            return "\n".join(f"{k}: {v}" for k, v in value.items())

        return str(value)
    
    # ==========================================================
    #  PARAGRAPH PLACEHOLDER REPLACEMENT
    # ==========================================================
    print("📄 Replacing placeholders in paragraphs...")
    replaced_count = 0
    for p in doc.paragraphs:
        for key, value in data.items():
            placeholder = f"[{key.upper()}]"
            if replace_placeholder_in_paragraph(p, placeholder, advanced_serialize(value)):
                replaced_count += 1
                print(f"   ✓ Replaced {placeholder} in paragraph")
    print(f"   Total paragraph replacements: {replaced_count}")

    
    # ==========================================================
    #  TABLE PLACEHOLDER REPLACEMENT (INCLUDING REPEAT)
    # ==========================================================
    print("📄 Replacing placeholders in tables (with REPEAT support)...")

    REPEAT_MARKER_RE = re.compile(r'^\s*\[REPEAT:([A-Z0-9_]+)\]\s*$', re.IGNORECASE)
    PLACEHOLDER_RE = re.compile(r'\[([A-Z0-9_]+)\]')

    def _replace_in_cell(cell: _Cell, mapping: dict):
        """
        Αντικατάσταση μέσα σε κελί με διατήρηση της μορφοποίησης (Bold, Color, κλπ).
        Αντί να κάνουμε reset το cell.text, τρέχουμε το replace_placeholder_in_paragraph
        για κάθε παράγραφο του κελιού.
        """
        replaced_any = False
        
        # Τρέχουμε για κάθε παράγραφο μέσα στο κελί
        for paragraph in cell.paragraphs:
            # Ελέγχουμε όλα τα κλειδιά που έχουμε διαθέσιμα (π.χ. TITLE, RISK_IMPACT)
            for key, val in mapping.items():
                placeholder = f"[{key}]"
                
                # Αν υπάρχει το placeholder, κάνουμε την "έξυπνη" αντικατάσταση
                if placeholder in paragraph.text:
                    if replace_placeholder_in_paragraph(paragraph, placeholder, val):
                        replaced_any = True
                        
        return replaced_any

    def _duplicate_row(table, row_idx: int):
        tr = table.rows[row_idx]._tr
        new_tr = deepcopy(tr)
        tr.addnext(new_tr)
        return table.rows[row_idx + 1]

    def fill_repeat_table(table, data_list: list, row_template_idx: int):
        if not isinstance(data_list, list) or not data_list:
            return
        for item in data_list:
            new_row = _duplicate_row(table, row_template_idx)
            mapping = (
                {k.upper(): advanced_serialize(v) for k, v in item.items()}
                if isinstance(item, dict)
                else {"VALUE": advanced_serialize(item)}
            )
            for cell in new_row.cells:
                _replace_in_cell(cell, mapping)
        # clear template row
        for cell in table.rows[row_template_idx].cells:
            cell.text = ""

    table_replaced = 0

    for tbl in doc.tables:
        repeat_key = None
        marker_row_idx = None

        # detect repeat marker row
        for ridx, row in enumerate(tbl.rows):
            first_cell_text = row.cells[0].text.strip() if row.cells else ""
            m = REPEAT_MARKER_RE.match(first_cell_text)
            if m:
                repeat_key = m.group(1).upper()
                marker_row_idx = ridx
                break

        if repeat_key and marker_row_idx is not None and (marker_row_idx + 1) < len(tbl.rows):
            data_list = data.get(repeat_key, []) or data.get(f"{repeat_key}_LIST", [])
            if data_list:
                fill_repeat_table(tbl, data_list, marker_row_idx + 1)
                for c in tbl.rows[marker_row_idx].cells:
                    c.text = ""
            else:
                parent = tbl._tbl.getparent()
                parent.remove(tbl._tbl)
                continue

        # single-cell replacement
        for row in tbl.rows:
            for cell in row.cells:
                for key, value in data.items():
                    ph = f"[{key.upper()}]"
                    if ph in cell.text:
                        if _replace_in_cell(cell, {key.upper(): advanced_serialize(value)}):
                            table_replaced += 1

    print(f"   Total table replacements: {table_replaced}")

    # ==========================================================
    #  SMART PLACEHOLDER FILLER
    # ==========================================================
    print("🧠 Applying smart placeholder filling...")
    doc = SmartPlaceholderFiller.fill_smart_placeholders(doc, data)
    print("✅ Smart placeholder filling completed")

    print("🎨 Applying Markdown Bold formatting...")
    apply_markdown_styling(doc)

    # ==========================================================
    #  SAVE DOCX → PDF
    # ==========================================================
    
    # -----------------------------------------------------------
    # ΑΛΛΑΓΗ 3: ΧΡΗΣΗ ΤΗΣ ΝΕΑΣ ΣΥΝΑΡΤΗΣΗΣ ΓΙΑ LINUX
    # -----------------------------------------------------------
    # from docx2pdf import convert (ΑΦΑΙΡΕΘΗΚΕ)

    output_dir = os.path.join(BASE_DIR, "generated_reports")
    os.makedirs(output_dir, exist_ok=True)

    # 1. Καθαρισμός ονόματος (Αφαιρούμε κενά και σύμβολα)
    safe_name = re.sub(r"[^A-Za-z0-9_-]+", "_", data.get("APPLICATION_NAME", "Report"))
    
    # 2. Μοναδικό ID (το κρατάμε στον server για να μην μπερδευτούν ταυτόχρονοι χρήστες)
    unique_id = uuid.uuid4().hex[:8]

    # 3. Δημιουργία ονόματος αρχείου με το Suffix που ζήτησες
    # Στον server θα σωθεί ως: AppName_EU_AI_Compliance_Report_UUID.docx
    base_filename = f"{safe_name}_EU_AI_Compliance_Report_{unique_id}"

    output_filename_docx = f"{base_filename}.docx"
    output_path_docx = os.path.join(output_dir, output_filename_docx)

    print(f"💾 Saving DOCX to: {output_path_docx}")
    doc.save(output_path_docx)

    output_filename_pdf = f"{base_filename}.pdf"
    output_path_pdf = os.path.join(output_dir, output_filename_pdf)

    # ΚΛΗΣΗ ΤΗΣ ΝΕΑΣ ΣΥΝΑΡΤΗΣΗΣ
    print(f"🔄 Converting to PDF via LibreOffice: {output_path_pdf}")
    # import pythoncom (ΑΦΑΙΡΕΘΗΚΕ)
    # pythoncom.CoInitialize() (ΑΦΑΙΡΕΘΗΚΕ)

    final_pdf = convert_docx_to_pdf_linux(output_path_docx, output_dir)

    if final_pdf:
        print("✅ PDF generated successfully")
        # Προαιρετικά σβήνεις το docx αν πέτυχε το PDF
        try:
            os.remove(output_path_docx)
            print("🗑️ Original DOCX deleted")
        except:
            pass
        return final_pdf
    else:
        print("⚠️ PDF generation failed, returning DOCX")
        return output_path_docx

# =============================================================================
#  ROBUST FILE EXTRACTOR (ZIP, PDF, DOCX, TXT) - FIXED
# =============================================================================

def read_file_content(file_stream, filename):
    """
    Διαβάζει μεμονωμένο αρχείο (stream) και επιστρέφει το κείμενο.
    Αναγνωρίζει PDF, DOCX, TXT, JSON, CSV, CODE.
    """
    ext = os.path.splitext(filename)[1].lower()
    text = ""
    
    # Reset stream pointer just in case
    file_stream.seek(0)

    try:
        # 1. PDF Handling
        if ext == ".pdf":
            try:
                reader = PdfReader(file_stream)
                for page in reader.pages:
                    extracted = page.extract_text()
                    if extracted:
                        text += extracted + "\n"
            except Exception as e:
                text += f"[Error reading PDF {filename}: {str(e)}]\n"

        # 2. Word (DOCX) Handling
        elif ext in [".docx", ".doc"]:
            try:
                doc = Document(file_stream)
                for para in doc.paragraphs:
                    text += para.text + "\n"
                # Εξαγωγή και από πίνακες για πληρότητα
                for table in doc.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            text += cell.text + " "
                    text += "\n"
            except Exception as e:
                text += f"[Error reading DOCX {filename}: {str(e)}]\n"

        # 3. Text / Code / Data Handling
        elif ext in [".txt", ".md", ".json", ".csv", ".xml", ".py", ".js", ".html", ".css", ".ini", ".log"]:
            try:
                content = file_stream.read()
                if isinstance(content, bytes):
                    # Προσπάθεια αποκωδικοποίησης utf-8
                    text += content.decode("utf-8", errors="ignore")
                else:
                    text += str(content)
            except Exception as e:
                text += f"[Error reading text file {filename}: {str(e)}]\n"
        
        else:
            # Αγνοούμε εικόνες ή άγνωστα αρχεία
            return None

    except Exception as e:
        return f"[Generic Error reading {filename}: {str(e)}]"

    if text.strip():
        # Βάζουμε διαχωριστικά για να καταλαβαίνει το LLM πού αρχίζει/τελειώνει το κάθε αρχείο
        return f"\n\n=== START OF FILE: {filename} ===\n{text}\n=== END OF FILE: {filename} ===\n"
    return None

def extract_supporting_docs_text(files):
    """
    Διαχειρίζεται λίστα αρχείων (και ZIPs αναδρομικά).
    Επιστρέφει ενιαίο string και λίστα ονομάτων.
    """
    final_text = []
    file_names = []

    for f in files or []:
        if not f or f.filename == '': continue
        
        filename = f.filename
        ext = os.path.splitext(filename)[1].lower()
        
        # Περίπτωση ZIP
        if ext == ".zip":
            file_names.append(f"{filename} (ZIP Archive)")
            try:
                # Διαβάζουμε το ZIP στη μνήμη
                f.seek(0)
                with zipfile.ZipFile(f) as z:
                    for inner_name in z.namelist():
                        # Αγνοούμε φακέλους και κρυφά αρχεία MACOSX
                        if inner_name.endswith('/') or '__MACOSX' in inner_name: 
                            continue
                        
                        # Άνοιγμα του εσωτερικού αρχείου ως stream
                        with z.open(inner_name) as inner_f:
                            # Μετατροπή σε BytesIO για να είναι seekable (το απαιτεί το pypdf/docx)
                            inner_stream = io.BytesIO(inner_f.read())
                            content = read_file_content(inner_stream, inner_name)
                            if content:
                                final_text.append(content)
                                file_names.append(f"-> {inner_name}")
            except Exception as e:
                print(f"❌ Zip Error in {filename}: {e}")
                final_text.append(f"[Error extracting ZIP {filename}: {e}]")

        # Περίπτωση Απλού Αρχείου
        else:
            file_names.append(filename)
            content = read_file_content(f, filename)
            if content: 
                final_text.append(content)

    return "".join(final_text), file_names

# =============================================================================
#  1. SHORT REPORT GENERATION (6 MODULES, FLASH ASSESSMENT)
# =============================================================================

def generate_short_report(params: dict, job_id=None) -> dict:
    """
    SHORT report (~8-10 σελίδες) με 6 modular prompts.
    - Χρησιμοποιεί /prompts/short/*.txt
    - Ενιαίο context από build_llm_context(params)
    - Κάθε module επιστρέφει ΜΟΝΟ τα δικά του keys
    - Στο merge ΔΕΝ αφήνουμε κενές τιμές να σβήσουν ήδη γεμάτα πεδία
    """

    prompts_dir = os.path.join(BASE_DIR, "prompts", "short")

    # Η λίστα με τα 6 νέα αρχεία που φτιάξαμε
    module_files = [
        "short_01_exec.txt",
        "short_02_system.txt",
        "short_03_classification.txt",
        "short_04_compliance.txt",
        "short_05_actions.txt",
        "short_06_appendix.txt",
    ]

    merged: dict = {}

    # Εσωτερικές βοηθητικές συναρτήσεις (ίδιες με standard/long)
    def uppercase_keys(obj):
        if isinstance(obj, dict):
            return {str(k).upper(): uppercase_keys(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [uppercase_keys(x) for x in obj]
        return obj

    def is_empty_value(v):
        if v is None:
            return True
        if isinstance(v, str) and v.strip() == "":
            return True
        if isinstance(v, (list, dict)) and len(v) == 0:
            return True
        return False

    print("🚀 Starting SHORT Report Generation...")

    for idx, filename in enumerate(module_files):
        if job_id and job_id in generation_jobs:
            clean_name = filename.split('_', 1)[-1].replace('.txt', '').replace('_', ' ').title()
            generation_jobs[job_id]['status'] = f"Ανάλυση Ενότητας {idx+1}/{len(module_files)}: {clean_name}..."
            generation_jobs[job_id]['progress'] = int((idx / len(module_files)) * 80)

        path = os.path.join(prompts_dir, filename)
        if not os.path.exists(path):
            print(f"⚠️ Missing SHORT module prompt: {filename}, skipping.")
            continue

        with open(path, "r", encoding="utf-8") as f:
            module_prompt = f.read()

        # Placeholder replace μέσα στο prompt text
        for k, v in params.items():
            module_prompt = module_prompt.replace(f"[{k}]", str(v))

        # Ενιαίο context + module-specific prompt
        user_content = build_llm_context(params) + "\n\n" + module_prompt

        print(f"🧩 Calling LLM for SHORT module: {filename}")
        
        try:
            response = client.chat.completions.create(
                model="gpt-4o",
                temperature=0.7,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are an EU AI Act compliance expert. "
                            "You ALWAYS answer ONLY with a single valid JSON object. "
                            "JSON KEYS MUST REMAIN IN ENGLISH AND UPPERCASE. "
                            "All JSON VALUES (text fields) MUST be written 100% "
                            "in the user-selected language specified in the context. "
                            "You MUST follow strictly the JSON schema and list of keys "
                            "given in the user message for this module. "
                            "Do not include Markdown formatting (```json) if possible."
                        ),
                    },
                    {"role": "user", "content": user_content},
                ],
                max_tokens=4000, # Το Short θέλει λιγότερα tokens ανά module
            )

            llm_output = response.choices[0].message.content.strip()
            
            # Χρήση της global extract_json_from_llm_output που έχεις στον κώδικά σου
            json_output = extract_json_from_llm_output(llm_output)

            if not json_output:
                print(f"⚠️ No JSON parsed for {filename}, skipping merge.")
                continue

            json_output = uppercase_keys(json_output)
            print(f"✅ JSON parsed successfully for {filename}! Fields: {len(json_output)}")

            # SMART MERGE LOGIC (Ίδια με Standard/Long)
            for k, v in json_output.items():
                if k not in merged:
                    merged[k] = v
                else:
                    # λίστα + λίστα → extend
                    if isinstance(merged[k], list) and isinstance(v, list):
                        merged[k].extend(v)
                    # άδειο → γεμάτο (override)
                    elif is_empty_value(merged[k]) and not is_empty_value(v):
                        merged[k] = v
                    # διαφορετικοί τύποι: αν το παλιό είναι “άδειο”, πάρε το νέο
                    elif type(merged[k]) != type(v) and is_empty_value(merged[k]) and not is_empty_value(v):
                        merged[k] = v
        
        except Exception as e:
            print(f"❌ Error generating module {filename}: {str(e)}")

    return merged

# =============================================================================
#  STANDARD REPORT GENERATION (11 modular prompts)
# =============================================================================
def generate_standard_report(params: dict, job_id=None) -> dict:
    """
    STANDARD report (~30 σελίδες) με modular prompts.
    - Χρησιμοποιεί /prompts/standard/*.txt
    - Ενιαίο context από build_llm_context(params)
    - Κάθε module επιστρέφει ΜΟΝΟ τα δικά του keys
    - Στο merge ΔΕΝ αφήνουμε κενές τιμές να σβήσουν ήδη γεμάτα πεδία
    """

    prompts_dir = os.path.join(BASE_DIR, "prompts", "standard")

    module_files = [
        "standard_01_02_setup.txt",
        "standard_03_core_compliance.txt",
        "standard_04_risk.txt",
        "standard_05_data_gov.txt",
        "standard_06_roadmap.txt",
        "standard_07_case_study.txt",
        "standard_08_appendix.txt",
    ]

    merged: dict = {}

    def uppercase_keys(obj):
        if isinstance(obj, dict):
            return {str(k).upper(): uppercase_keys(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [uppercase_keys(x) for x in obj]
        return obj

    def is_empty_value(v):
        # Ό,τι είναι "", None, [] ή μόνο whitespace το θεωρούμε “άδειο”
        if v is None:
            return True
        if isinstance(v, str) and v.strip() == "":
            return True
        if isinstance(v, (list, dict)) and len(v) == 0:
            return True
        return False

    for idx, filename in enumerate(module_files):
        if job_id and job_id in generation_jobs:
            clean_name = filename.split('_', 1)[-1].replace('.txt', '').replace('_', ' ').title()
            generation_jobs[job_id]['status'] = f"Αξιολόγηση Ενότητας {idx+1}/{len(module_files)}: {clean_name}..."
            generation_jobs[job_id]['progress'] = int((idx / len(module_files)) * 80)

        path = os.path.join(prompts_dir, filename)
        if not os.path.exists(path):
            print(f"⚠️ Missing standard module prompt: {filename}, skipping.")
            continue

        with open(path, "r", encoding="utf-8") as f:
            module_prompt = f.read()

        # Placeholder replace μέσα στο prompt (π.χ. [APPLICATION_NAME])
        for k, v in params.items():
            module_prompt = module_prompt.replace(f"[{k}]", str(v))

        # Ενιαίο context + module-specific οδηγίες
        user_content = build_llm_context(params) + "\n\n" + module_prompt

        print(f"🧩 Calling LLM for module: {filename}")
        response = client.chat.completions.create(
            model="gpt-4o",
            temperature=0.7,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an EU AI Act compliance expert. "
                        "You ALWAYS answer ONLY with a single valid JSON object. "
                        "JSON KEYS MUST REMAIN IN ENGLISH AND UPPERCASE. "
                        "All JSON VALUES (text fields) MUST be written 100% "
                        "in the user-selected language specified in the context. "
                        "You MUST follow strictly the JSON schema and list of keys "
                        "given in the user message for this module and MUST NOT "
                        "add extra keys that are not requested."
                    ),
                },
                {"role": "user", "content": user_content},
            ],
            max_tokens=8000,
        )

        llm_output = response.choices[0].message.content.strip()
        json_output = extract_json_from_llm_output(llm_output)

        if not json_output:
            print(f"⚠️ No JSON parsed for {filename}, skipping merge.")
            continue

        json_output = uppercase_keys(json_output)
        print(f"✅ JSON parsed successfully! Fields: {len(json_output)}")

        # MERGE: δεν αφήνουμε άδεια values να σβήνουν γεμάτα πεδία
        for k, v in json_output.items():
            if k not in merged:
                merged[k] = v
            else:
                # Αν το νέο v είναι “γεμάτο” και το παλιό είναι κενό, κάνε override.
                if not is_empty_value(v) and is_empty_value(merged[k]):
                    merged[k] = v

    return merged

# =============================================================================
#  LONG REPORT GENERATION (15 MODULES, DEEP ANALYSIS)
# =============================================================================

def generate_long_report(params: dict, job_id=None) -> dict:
    """
    LONG report (~100+ σελίδες) με 15 modular prompts.
    - Χρησιμοποιεί /prompts/long/*.txt (τα long_prompts_v3)
    - Κάθε module επιστρέφει ΜΟΝΟ τα δικά του keys (flat JSON)
    - Κάνουμε merge όλων των modules σε ένα ενιαίο dict
    - Δεν σβήνουμε γεμάτα πεδία με άδεια
    - Για λίστες, κάνουμε extend για να γεμίζουν πίνακες (π.χ. RISK_REGISTER, GAPS_LIST)
    """

    prompts_dir = os.path.join(BASE_DIR, "prompts", "long")

    module_files = [
        "long_01_exec_briefing.txt",
        "long_02_exec_summary.txt",
        "long_03_system_context.txt",
        "long_04_scope_regulatory.txt",
        "long_05_architecture.txt",
        "long_06_datasets.txt",
        "long_07_model_card.txt",
        "long_08_training_deployment.txt",
        "long_09_risk_analysis.txt",
        "long_10_compliance.txt",
        "long_11_governance.txt",
        "long_12_findings.txt",
        "long_13_quantitative.txt",
        "long_14_case_studies.txt",
        "long_15_appendices.txt",
    ]

    merged: dict = {}

    def uppercase_keys(obj):
        if isinstance(obj, dict):
            return {str(k).upper(): uppercase_keys(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [uppercase_keys(x) for x in obj]
        return obj

    def is_empty_value(v):
        if v is None:
            return True
        if isinstance(v, str) and v.strip() == "":
            return True
        if isinstance(v, (list, dict)) and len(v) == 0:
            return True
        return False

    for idx, filename in enumerate(module_files):
        if job_id and job_id in generation_jobs:
            clean_name = filename.split('_', 1)[-1].replace('.txt', '').replace('_', ' ').title()
            generation_jobs[job_id]['status'] = f"Βαθιά Σάρωση Ενότητας {idx+1}/{len(module_files)}: {clean_name}..."
            generation_jobs[job_id]['progress'] = int((idx / len(module_files)) * 80)

        path = os.path.join(prompts_dir, filename)
        if not os.path.exists(path):
            print(f"⚠️ Missing LONG module prompt: {filename}, skipping.")
            continue

        with open(path, "r", encoding="utf-8") as f:
            module_prompt = f.read()

        # Replace π.χ. [APPLICATION_NAME], [DATE], [AUTHOR], [REPORT_TYPE] κλπ μέσα στο prompt,
        # ώστε το LLM να έχει πλήρες context.
        prompt_text = module_prompt
        for k, v in params.items():
            placeholder = f"[{k}]"
            if placeholder in prompt_text:
                prompt_text = prompt_text.replace(placeholder, str(v))

        # Ενιαίο context (build_llm_context) + module-specific prompt
        user_content = build_llm_context(params) + "\n\n" + prompt_text

        print(f"🧩 Calling LLM for LONG module: {filename}")
        response = client.chat.completions.create(
            model="gpt-4o",
            temperature=0.7,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an EU AI Act compliance expert and auditor. "
                        "You ALWAYS answer ONLY with a single valid JSON object. "
                        "JSON KEYS MUST REMAIN IN ENGLISH AND UPPERCASE. "
                        "All JSON VALUES (text fields) MUST be written 100% "
                        "in the user-selected language specified in the context. "
                        "You MUST strictly obey the JSON schema and key list "
                        "specified in the user message for this module and MUST NOT "
                        "add extra top-level keys that are not requested. "
                        "Never output text outside the JSON object. "
                        "You must provide long-form, deeply analytical, "
                        "data-rich content (statistics, numerical values, "
                        "quantitative interpretation) wherever relevant."
                    ),
                },
                {"role": "user", "content": user_content},
            ],
            max_tokens=12000,
        )

        llm_output = response.choices[0].message.content.strip()
        json_output = extract_json_from_llm_output(llm_output)

        if not json_output:
            print(f"⚠️ No JSON parsed for LONG module {filename}, skipping merge.")
            continue

        json_output = uppercase_keys(json_output)
        print(f"✅ LONG JSON parsed successfully for {filename}! Fields: {len(json_output)}")

        # MERGE ΛΟΓΙΚΗ:
        # - Αν το νέο value είναι “γεμάτο” και το παλιό είναι κενό → override
        # - Αν και τα δύο είναι λίστα → extend (για να μεγαλώνουν πίνακες)
        # - Αλλιώς αφήνουμε το παλιό όπως είναι
        for k, v in json_output.items():
            if k not in merged:
                merged[k] = v
            else:
                # λίστα + λίστα → extend
                if isinstance(merged[k], list) and isinstance(v, list):
                    merged[k].extend(v)
                # άδειο → γεμάτο
                elif is_empty_value(merged[k]) and not is_empty_value(v):
                    merged[k] = v
                # διαφορετικοί τύποι: αν το παλιό είναι “άδειο” και το νέο γεμάτο → πάρε το νέο
                elif type(merged[k]) != type(v) and is_empty_value(merged[k]) and not is_empty_value(v):
                    merged[k] = v

    return merged

def expand_query_if_needed(params):
    description = params.get('APPLICATION_DESCRIPTION', '').strip()
    app_name = params.get('APPLICATION_NAME', '')
    app_url = params.get('APPLICATION_URL', '')
    
    # Αν η περιγραφή είναι μικρότερη από 30 χαρακτήρες, το LLM την επεκτείνει αυτόματα
    if len(description) < 30 and (app_name or app_url):
        print(f"⚡ Smart Query Expansion: Description too short. Auto-expanding via LLM for {app_name}...")
        expansion_prompt = (
            f"Provide a brief, 2-sentence technical description of what the AI application '{app_name}' "
            f"(accessible at {app_url}) does, focusing on its domain, purpose, and potential risk areas under AI regulations."
        )
        try:
            response = client.chat.completions.create(
                model="gpt-4o-mini", # Χρησιμοποιούμε το mini για αστραπιαία ταχύτητα και ελάχιστο κόστος
                messages=[{"role": "user", "content": expansion_prompt}],
                max_tokens=100
            )
            expanded_desc = response.choices[0].message.content.strip()
            print(f"✅ Auto-expanded description: {expanded_desc}")
            return f"{app_name} - {expanded_desc}"
        except Exception as e:
            print(f"⚠️ Expansion Error: {e}")
            
    return f"Domain: {params.get('APPLICATION_AREA', '')}. Description: {description}. Role: {params.get('ORGANIZATION_ROLE', '')}"

# =============================================================================
#  FLASK ROUTES
# =============================================================================

@app.route("/")
def landing_page():
    return render_template("landing.html")

@app.route("/form")
def form_page():
    return render_template("form.html")

@app.route("/generate-report", methods=["POST"])
def generate_report():
    try:
        print("\n" + "="*80)
        print("🚀 Starting report generation...")
        print("="*80)

        # -------------------------------------------------
        # 1. INITIALIZE & DATE SETUP
        # -------------------------------------------------
        details_value = request.form.get("details") or request.form.get("report_type")
        
        # Timezone Athens
        tz = pytz.timezone("Europe/Athens")
        official_date_str = datetime.now(tz).strftime("%d/%m/%Y")

        params = {
            "details": details_value,
            "AUTHOR": request.form.get("author", "Automated System"),
            "DATE": official_date_str,
            "REPORT_DATE": official_date_str,
            "CURRENT_DATE": official_date_str,
            "input_mode": request.form.get("input_mode") or "application",
            "LANGUAGE": request.form.get("language", "en"),
            "APPLICATION_NAME": "AI System", # Default placeholder
            "SUPPORTING_DOCS_TEXT": "",      # Default empty
            "supporting_filenames": []
        }

        # -------------------------------------------------
        # 2. HANDLE INPUT MODES (Application vs Files)
        # -------------------------------------------------
        
        # ---- CASE A: Application URL / Description Mode ----
        if params["input_mode"] == "application":
            print("📝 Mode: Application Input")
            # Χρησιμοποιούμε 'app_name' γιατί αυτό γράφει το HTML σου
            params["APPLICATION_NAME"] = request.form.get("app_name") or "AI System"
            
            # Χρησιμοποιούμε 'app_url' γιατί αυτό γράφει το HTML σου
            params["application_url"] = request.form.get("app_url")
            
            params["application_summary"] = request.form.get("application_description")
            params["application_area"] = request.form.get("application_area")
            params["organization_role"] = request.form.get("organization_role")
            params["risk_category"] = request.form.get("risk_category")

        # ---- CASE B: Files Upload Mode ----
        elif params["input_mode"] == "files":
            print("📂 Mode: Files Upload")
            files = request.files.getlist("supporting_files")
            
            # Εξαγωγή κειμένου από τα αρχεία
            supporting_text, filenames = extract_supporting_docs_text(files)
            
            params["SUPPORTING_DOCS_TEXT"] = supporting_text
            params["supporting_filenames"] = filenames
            
            print(f"   📄 Processed {len(filenames)} files.")
            print(f"   📊 Extracted text length: {len(supporting_text)} chars")

            # --- Χειρισμός Ονόματος Εφαρμογής (Fallback Logic) ---
            req_app_name = request.form.get("application_name_files")
            if req_app_name:
                # Ο χρήστης έδωσε όνομα στη φόρμα αρχείων
                params["APPLICATION_NAME"] = req_app_name
            elif filenames:
                # Δεν έδωσε όνομα -> Παίρνουμε το όνομα του 1ου αρχείου (χωρίς κατάληξη)
                # π.χ. "My_App_Spec.pdf" -> "My App Spec"
                base_name = os.path.splitext(filenames[0])[0] # (π.χ. My_App_Spec)
                clean_name = base_name.replace("_", " ").replace("-", " ") 
                params["APPLICATION_NAME"] = clean_name.title() # "My App Spec"
            else:
                params["APPLICATION_NAME"] = "Unnamed AI Application"

            # --- Λοιπά Metadata από το Files Tab ---
            params["organization_role"] = request.form.get("organization_role_files")
            params["risk_category"] = request.form.get("risk_category_files")
            
            # Σημαντικό: Καθαρίζουμε το summary για να ενεργοποιηθεί 
            # η λογική "Extract from Files" στο build_llm_context
            params["application_summary"] = "" 
            
            # Αν δεν έχει επιλεγεί Application Area, βάζουμε "General" για να μην σκάσει
            params["application_area"] = "Determined by Documentation"

        # -------------------------------------------------
        # 3. NORMALIZE PARAMS FOR TEMPLATES & PROMPTS
        # -------------------------------------------------
        # Δημιουργούμε UPPERCASE aliases γιατί τα prompts/templates τα ζητάνε έτσι
        params["APPLICATION_URL"] = params.get("application_url", "")
        params["APPLICATION_DESCRIPTION"] = params.get("application_summary", "")
        params["APPLICATION_AREA"] = params.get("application_area", "")
        params["ORGANIZATION_ROLE"] = params.get("organization_role", "")
        params["RISK_CATEGORY"] = params.get("risk_category") or "Not classified"
        params["WEBSITE_URL"] = params.get("application_url", "")

        print(f"📥 Final Params Check: Name='{params['APPLICATION_NAME']}', Mode='{params['input_mode']}'")

        if not params["details"]:
            return jsonify({"error": "No report type selected"}), 400

        # ΑΡΧΙΚΟΠΟΙΗΣΗ ΤΟΥ JOB
        job_id = str(uuid.uuid4())
        generation_jobs[job_id] = {
            'progress': 0, 
            'status': 'Αρχικοποίηση συστήματος...', 
            'result_file': None, 
            'error': None,
            'download_name': 'Veritas4AI_Report.pdf'
        }
        
        # Start the background task thread
        thread = threading.Thread(target=run_generation_task, args=(job_id, params))
        thread.start()
        
        return jsonify({'job_id': job_id})

    except Exception as e:
        print("\n❌ ERROR GENERATING REPORT")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

def run_generation_task(job_id, params):
    try:
        # -------------------------------------------------
        # 4. GENERATE DATA VIA LLM
        # -------------------------------------------------
        if params["details"] == "short":
            print("📘 Generating SHORT report...")
            final_data = generate_short_report(params, job_id=job_id)

        elif params["details"] == "standard":
            print("📘 Generating STANDARD report...")
            final_data = generate_standard_report(params, job_id=job_id)

        elif params["details"] == "long":
            print("📘 Generating LONG report...")
            final_data = generate_long_report(params, job_id=job_id)

        else:
            raise ValueError("Invalid detail level")

        # -------------------------------------------------
        # 5. MERGE METADATA INTO FINAL DATA
        # -------------------------------------------------
        # Βεβαιωνόμαστε ότι τα βασικά πεδία υπάρχουν στο τελικό JSON
        # (ώστε να μπουν σωστά στο Word template ακόμα και αν το LLM τα ξέχασε)
        final_data["APPLICATION_NAME"] = params.get("APPLICATION_NAME")
        final_data["APPLICATION_URL"] = params.get("APPLICATION_URL")
        final_data["APPLICATION_AREA"] = params.get("APPLICATION_AREA")
        final_data["ORGANIZATION_ROLE"] = params.get("ORGANIZATION_ROLE")
        final_data["RISK_CATEGORY"] = final_data.get("RISK_CATEGORY") or params.get("RISK_CATEGORY")
        final_data["LANGUAGE"] = params.get("LANGUAGE")
        final_data["AUTHOR"] = params.get("AUTHOR")
        final_data["DATE"] = params.get("DATE")
        final_data["REPORT_DATE"] = params.get("REPORT_DATE")
        final_data["REPORT_TYPE"] = params.get("details", "").upper()
        
        # Αν το LLM δεν έφτιαξε περιγραφή (σπάνιο), βάζουμε την αρχική
        if not final_data.get("APPLICATION_DESCRIPTION") and params.get("APPLICATION_DESCRIPTION"):
             final_data["APPLICATION_DESCRIPTION"] = params.get("APPLICATION_DESCRIPTION")

        generation_jobs[job_id]['status'] = 'Σύνθεση του τελικού εγγράφου Word...'
        generation_jobs[job_id]['progress'] = 85

        # -------------------------------------------------
        # 6. FILL TEMPLATE & EXPORT PDF
        # -------------------------------------------------
        template_file = os.path.join(
            BASE_DIR,
            "templates_files",
            f"{params['details']}_template.docm"
        )
        print(f"\n📄 Filling template: {template_file}\n")

        filled_pdf_path = fill_template(template_file, final_data)
        print(f"📤 Returning generated PDF: {filled_pdf_path}")

        # --- ΚΑΘΑΡΟ ΟΝΟΜΑ ΓΙΑ ΤΟ DOWNLOAD ---
        # Παίρνουμε το όνομα, καθαρίζουμε σύμβολα
        clean_name = re.sub(r"[^A-Za-z0-9_-]+", "_", final_data.get("APPLICATION_NAME", "Report"))
        
        # Φτιάχνουμε το τελικό όνομα που βλέπει ο χρήστης
        # Π.χ. "Medical_Scanner_EU_AI_Compliance_Report.pdf"
        user_download_name = f"{clean_name}_EU_AI_Compliance_Report.pdf"

        generation_jobs[job_id]['status'] = 'Ολοκληρώθηκε!'
        generation_jobs[job_id]['progress'] = 100
        generation_jobs[job_id]['result_file'] = filled_pdf_path
        generation_jobs[job_id]['download_name'] = user_download_name

    except Exception as e:
        print("\n❌ ERROR IN GENERATION TASK")
        traceback.print_exc()
        if job_id in generation_jobs:
            generation_jobs[job_id]['error'] = str(e)

@app.route('/stream-progress/<job_id>')
def stream_progress(job_id):
    def generate():
        while True:
            job = generation_jobs.get(job_id)
            if not job:
                yield f"data: {json.dumps({'error': 'Το Report δεν βρέθηκε ή έληξε'})}\n\n"
                break
            
            yield f"data: {json.dumps(job)}\n\n"
            
            if job['result_file'] or job['error']:
                break
                
            time.sleep(1.0)
    return Response(stream_with_context(generate()), mimetype='text/event-stream')

@app.route('/download-report/<job_id>')
def download_report(job_id):
    job = generation_jobs.get(job_id)
    if job and job.get('result_file'):
        return send_file(
            job['result_file'],
            as_attachment=True,
            download_name=job.get('download_name'),
            mimetype="application/pdf"
        )
    return "File not found", 404

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("🔍 STARTUP CHECKS")
    print("=" * 80)

    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️  WARNING: OPENAI_API_KEY not set")
    else:
        print("✅ OPENAI_API_KEY found")

    required_folders = {
        'templates': 'HTML templates',
        'static': 'Static files',
        'prompts': 'LLM prompts',
        'templates_files': 'Word templates'
    }

    print(f"\n🔍 Checking folders:")
    for folder, description in required_folders.items():
        folder_path = os.path.join(BASE_DIR, folder)
        if os.path.exists(folder_path):
            file_count = len([
                f for f in os.listdir(folder_path)
                if os.path.isfile(os.path.join(folder_path, f))
            ])
            print(f"   ✅ {folder:20s} ({description}) - {file_count} files")
        else:
            print(f"   ❌ {folder:20s} - NOT FOUND")

    print(f"\n📄 Checking templates & prompts:")
    for template_type in ['short', 'standard', 'long']:
        template_path = os.path.join(BASE_DIR, "templates_files", f"{template_type}_template.docm")
        template_exists = os.path.exists(template_path)

        # Διόρθωση ελέγχου για τα Prompts
        if template_type == "short":
            prompt_exists = os.path.exists(os.path.join(BASE_DIR, "prompts", "short", "short_01_exec.txt"))
        elif template_type == "standard":
            prompt_exists = os.path.exists(os.path.join(BASE_DIR, "prompts", "standard", "standard_01_02_setup.txt"))
        elif template_type == "long":
            prompt_exists = os.path.exists(os.path.join(BASE_DIR, "prompts", "long", "long_01_exec_briefing.txt"))
        else:
            prompt_exists = False

        status = "✅" if (template_exists and prompt_exists) else "⚠️"
        print(f"   {status} {template_type:10s} - Template: {template_exists}, Prompt(s): {prompt_exists}")

    print("=" * 80)
    print("🚀 Starting EU AI Act Compliance Tool...")
    print(f"   Base directory: {BASE_DIR}")
    print(f"   Debug mode: ON")
    print(f"   Host: 0.0.0.0")
    print(f"   Port: 5005")
    print("=" * 80 + "\n")

    app.run(debug=True, host="0.0.0.0", port=5005)